<?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div id="modalDelete<?php echo e($p->pid); ?>" class="modal">
    <div class="modal-content">
        <span class="close-btn">&times;</span>
        <h2>Konfirmasi Hapus</h2>
        <p>Apakah Anda yakin ingin menghapus produk ini?</p>
        <form action="<?php echo e(route('produk.destroy', $p->pid)); ?>" method="POST">
            <?php echo method_field('DELETE'); ?>
            <?php echo csrf_field(); ?>
            <button type="submit">Hapus</button>
        </form>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\Project\Web\bamboo\resources\views/modal/modal-delet.blade.php ENDPATH**/ ?>