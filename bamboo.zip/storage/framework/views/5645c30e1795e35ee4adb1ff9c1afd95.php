
<?php $__env->startSection('content'); ?>
<div id="myBtn" class="bg-tambah-data">
    <div id="bo-tambah-data">
        <div class="icon-tambah-data">
            <span class="material-symbols-outlined">
            add
            </span>                                                        
        </div>
        <div id="text">
            <strong>Services</strong>
        </div>
    </div>
</div>

<?php if($errors->any()): ?>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        document.getElementById("myModal").style.display = "block";
    });
</script>
<?php endif; ?>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<div id="bg-isi-content" class="clearfix">
    <div id="bo-isi-content">
        
        <div id="table-pimpinan">
            <table>
                <thead>
                    <tr>
                        <th></th>
                        <th>No</th>
                        <th>Image</th>
                        <th>Nama</th>
                        <th>Deskripsi</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <div class="btn-details">
                                <span class="material-symbols-outlined">
                                add
                                </span>                                                        
                            </div>
                        </td>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e(asset('/storage/' . $p->img)); ?></td>
                        <td><?php echo e($p->judul); ?></td>
                        <td><?php echo e($p->desc); ?></td>
                        <td>
                            <div id="btn-cfg">
                                <div class="btn-edit" data-id="<?php echo e($p->id); ?>">
                                    <span class="material-symbols-outlined">
                                    edit
                                    </span>                                                       
                                </div>
                                <div class="btn-delete" data-id="<?php echo e($p->id); ?>">
                                    <span class="material-symbols-outlined">
                                    delete
                                    </span>                                                       
                                </div>
                            </div>
                        </td>
                    </tr>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Modal -->
<div id="myModal" class="modal">
    <div class="modal-content">
      <span class="close">&times;</span>
      <form action="<?php echo e(route('services.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
          <div id="head-modul">
            <h1>Tambah Service</h1>
          </div>
          <div class="thumbnail">
            <img id="thumbnail-preview" src="https://via.placeholder.com/100" alt="Thumbnail">
            <input type="file" id="thumbnail" name="img">
            <?php if($errors->has('img')): ?>
                <p class="alert alert-danger"><?php echo e($errors->first('img')); ?></p>
            <?php endif; ?>
          </div>
          <div class="form-group">
              <label for="name">Judul Service <span class="required">*</span></label>
              <input type="text" id="name" name="judul" placeholder="Masukan Judul" value="<?php echo e(old('judul')); ?>">
              <?php if($errors->has('judul')): ?>
                  <p class="alert alert-danger"><?php echo e($errors->first('judul')); ?></p>
              <?php endif; ?>
          </div>
          <div class="form-group">
              <label for="desc">Deskripsi <span class="required">*</span></label>
              <input type="text" id="desc" name="desc" placeholder="Masukan desc" value="<?php echo e(old('desc')); ?>">
              <?php if($errors->has('desc')): ?>
                  <p class="alert alert-danger"><?php echo e($errors->first('desc')); ?></p>
              <?php endif; ?>
          </div>
          <div class="form-group">
            <button type="submit" class="submit-btn">Submit</button>
          </div>
      </form>
    </div>
</div>

<!-- Edit Modals -->
<?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div id="editModal-<?php echo e($p->id); ?>" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <form action="<?php echo e(route('services.update', $p->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div id="head-modul">
                <h1>Edit Service</h1>
            </div>
            <div class="thumbnail">
                <input type="hidden" name="oldImage" value="<?php echo e($p->img); ?>">
                <img id="thumbnail-preview-<?php echo e($p->id); ?>" src="<?php echo e(asset('/storage/' . $p->img)); ?>" alt="Thumbnail">
                <input type="file" id="thumbnail-<?php echo e($p->id); ?>" name="img">
                <?php if($errors->has('img')): ?>
                    <p class="alert alert-danger"><?php echo e($errors->first('img')); ?></p>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="name-<?php echo e($p->id); ?>">Judul Service <span class="required">*</span></label>
                <input type="text" id="name-<?php echo e($p->id); ?>" name="judul" placeholder="Masukan Nama" value="<?php echo e(old('judul', $p->judul)); ?>">
                <?php if($errors->has('judul')): ?>
                    <p class="alert alert-danger"><?php echo e($errors->first('judul')); ?></p>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="desc-<?php echo e($p->id); ?>">desc <span class="required">*</span></label>
                <input type="text" id="desc-<?php echo e($p->id); ?>" name="desc" placeholder="Masukan desc" value="<?php echo e(old('desc', $p->desc)); ?>">
                <?php if($errors->has('desc')): ?>
                    <p class="alert alert-danger"><?php echo e($errors->first('desc')); ?></p>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <button type="submit" class="submit-btn">Submit</button>
            </div>
        </form>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<!-- Delete Modal -->
<?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div id="deleteModal-<?php echo e($p->id); ?>" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <form action="<?php echo e(route('services.destroy', $p->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <div id="head-modul">
                <h1>Delete Service</h1>
            </div>
            <p>Are you sure you want to delete <?php echo e($p->judul); ?>?</p>
            <div class="form-group">
                <button type="submit" class="submit-btn">Delete</button>
            </div>
        </form>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>
    $(document).ready(function () {
    $(".btn-details").on("click", function () {
        var row = $(this).closest("tr").next(".details-row");
        row.toggle();
        var icon = $(this).find(".material-symbols-outlined");
        if (row.is(":visible")) {
            icon.text("remove");
            $(this).addClass("red");
        } else {
            icon.text("add");
            $(this).removeClass("red");
        }
    });

    function showModal(modalId) {
        $(modalId).show();
    }

    function hideModals() {
        $(".modal").hide();
    }

    $("#myBtn").on("click", function () {
        showModal("#myModal");
    });

    $(".close").on("click", function () {
        hideModals();
    });

    $(window).on("click", function (event) {
        if ($(event.target).hasClass("modal")) {
            hideModals();
        }
    });

    $('.thumbnail').on('click', function() {
        $(this).find('input[type="file"]').click();
    });

    $('input[type="file"]').on('change', function(event) {
        var reader = new FileReader();
        var preview = $(this).siblings('img');
        reader.onload = function() {
            preview.attr('src', reader.result);
        }
        reader.readAsDataURL(event.target.files[0]);
    });

    // Event listener for Edit button
    $(".btn-edit").on("click", function () {
        var ppid = $(this).data('id');
        showModal("#editModal-" + ppid);
    });

    // Event listener for Delete button
    $(".btn-delete").on("click", function () {
        var ppid = $(this).data('id');
        showModal("#deleteModal-" + ppid);
    });
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('halaman.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Web\bamboo\resources\views/admin/service_view/services_view.blade.php ENDPATH**/ ?>