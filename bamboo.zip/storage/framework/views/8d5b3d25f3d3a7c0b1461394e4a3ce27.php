<?php $__env->startSection('content'); ?>
<div id="myBtn" class="bg-tambah-data">
    <div id="bo-tambah-data">
        <div class="icon-tambah-data">
            <span class="material-symbols-outlined">
            add
            </span>                                                        
        </div>
        <div id="text">
            <strong>Admin</strong>
        </div>
    </div>
</div>

<?php if($errors->any()): ?>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        document.getElementById("myModal").style.display = "block";
    });
</script>
<?php endif; ?>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<div id="bg-isi-content" class="clearfix">
    <div id="bo-isi-content">
        <div id="table-admin">
            <table>
                <thead>
                    <tr>
                        <th></th>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Username</th>
                        <th>Status</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <div class="btn-details">
                                <span class="material-symbols-outlined">
                                add
                                </span>                                                        
                            </div>
                        </td>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($u->name); ?></td>
                        <td><?php echo e($u->username); ?></td>
                        <td>aktif</td>
                        <td>
                            <div id="btn-cfg">
                                <div class="btn-edit" data-id="<?php echo e($u->id); ?>" data-toggle="modal" data-target="#editModal-<?php echo e($u->id); ?>">
                                    <span class="material-symbols-outlined">
                                    edit
                                    </span>                                                       
                                </div>
                                <div class="btn-delete" data-id="<?php echo e($u->id); ?>" data-toggle="modal" data-target="#deleteModal-<?php echo e($u->id); ?>">
                                    <span class="material-symbols-outlined">
                                    delete
                                    </span>                                                       
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr class="details-row">
                        <td colspan="6">
                            <div><strong>Nama Admin: </strong> <?php echo e($u->name); ?></div>
                            <div><strong>Role: </strong> <?php echo e($u->role->name); ?></div>
                            <div><strong>Status : </strong> Aktif</div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Modal -->
<div id="myModal" class="modal">
    <div class="modal-content">
      <span class="close">&times;</span>
      <form action="<?php echo e(route('admin.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
          <div id="head-modul">
            <h1>Tambah Admin</h1>
          </div>
          <div class="form-group">
              <label for="name">Nama Admin <span class="required">*</span></label>
              <input type="text" id="name" name="name" placeholder="Masukan Nama" value="<?php echo e(old('name')); ?>">
              <?php if($errors->has('name')): ?>
                  <p class="alert alert-danger"><?php echo e($errors->first('name')); ?></p>
              <?php endif; ?>
          </div>
          <div class="form-group">
              <label for="username">Username <span class="required">*</span></label>
              <input type="text" id="username" name="username" placeholder="Masukan Username" value="<?php echo e(old('username')); ?>">
              <?php if($errors->has('username')): ?>
                  <p class="alert alert-danger"><?php echo e($errors->first('username')); ?></p>
              <?php endif; ?>
          </div>
          <div class="form-group">
              <label for="password">Password <span class="required">*</span></label>
              <input type="password" id="password" name="password" placeholder="Masukan Password">
              <?php if($errors->has('password')): ?>
                  <p class="alert alert-danger"><?php echo e($errors->first('password')); ?></p>
              <?php endif; ?>
          </div>
          <div class="form-group">
              <label for="password_confirm">Konfirmasi Password <span class="required">*</span></label>
              <input type="password" name="password_confirm" placeholder="Konfirmasi Password">
              <?php if($errors->has('password_confirm')): ?>
                  <p class="alert alert-danger"><?php echo e($errors->first('password_confirm')); ?></p>
              <?php endif; ?>
          </div>
          <input type="text" id="role" name="role_id" required value="2" hidden>
          <input type="text" id="status" name="status" value="aktif" hidden>
          <div class="form-group">
            <button type="submit" class="submit-btn">Submit</button>
          </div>
      </form>
    </div>
</div>

<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!-- Edit Modal -->
<div id="editModal-<?php echo e($u->id); ?>" class="modal">
    <div class="modal-content">
      <span class="close">&times;</span>
      <form action="<?php echo e(route('admin.update', $u->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
          <div id="head-modul">
            <h1>Edit Admin</h1>
          </div>
          <input type="hidden" id="edit-id-<?php echo e($u->id); ?>" name="id" value="<?php echo e($u->id); ?>">
          <div class="form-group">
              <label for="edit-name-<?php echo e($u->id); ?>">Nama Admin <span class="required">*</span></label>
              <input type="text" id="edit-name-<?php echo e($u->id); ?>" name="name" placeholder="Masukan Nama" value="<?php echo e($u->name); ?>">
              <?php if($errors->has('name')): ?>
                  <p class="alert alert-danger"><?php echo e($errors->first('name')); ?></p>
              <?php endif; ?>
          </div>
          <div class="form-group">
              <label for="edit-username-<?php echo e($u->id); ?>">Username <span class="required">*</span></label>
              <input type="text" id="edit-username-<?php echo e($u->id); ?>" name="username" placeholder="Masukan Username" value="<?php echo e($u->username); ?>" readonly>
              <?php if($errors->has('username')): ?>
                  <p class="alert alert-danger"><?php echo e($errors->first('username')); ?></p>
              <?php endif; ?>
          </div>
          <div class="form-group">
              <label for="edit-password-<?php echo e($u->id); ?>">Password <span class="required">*</span></label>
              <input type="password" id="edit-password-<?php echo e($u->id); ?>" name="password" placeholder="Masukan Password">
              <?php if($errors->has('password')): ?>
                  <p class="alert alert-danger"><?php echo e($errors->first('password')); ?></p>
              <?php endif; ?>
          </div>
          <div class="form-group">
              <label for="edit-password_confirm-<?php echo e($u->id); ?>">Konfirmasi Password <span class="required">*</span></label>
              <input type="password" id="edit-password_confirm-<?php echo e($u->id); ?>" name="password_confirm" placeholder="Konfirmasi Password">
              <?php if($errors->has('password_confirm')): ?>
                  <p class="alert alert-danger"><?php echo e($errors->first('password_confirm')); ?></p>
              <?php endif; ?>
          </div>
          <input type="text" id="edit-role-<?php echo e($u->id); ?>" name="role_id" required value="2" hidden>
          <input type="text" id="edit-status-<?php echo e($u->id); ?>" name="status" value="aktif" hidden>
          <div class="form-group">
            <button type="submit" class="submit-btn">Update</button>
          </div>
      </form>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!-- Delete Modal -->
<div id="deleteModal-<?php echo e($u->id); ?>" class="modal">
    <div class="modal-content">
      <span class="close">&times;</span>
      <h1>Konfirmasi Hapus</h1>
      <p>Apakah Anda yakin ingin menghapus admin ini?</p>
      <form action="<?php echo e(route('admin.destroy', $u->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <div class="form-group">
            <button type="submit" class="submit-btn">Hapus</button>
        </div>
      </form>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>
    $(document).ready(function () {
        $(".btn-details").on("click", function () {
            var row = $(this).closest("tr").next(".details-row");
            row.toggle();
            var icon = $(this).find(".material-symbols-outlined");
            if (row.is(":visible")) {
                icon.text("remove");
                $(this).addClass("red");
            } else {
                icon.text("add");
                $(this).removeClass("red");
            }
        });

        // Function to show modal
        function showModal(modalId) {
            $(modalId).show();
        }

        // Function to hide all modals
        function hideModals() {
            $(".modal").hide();
        }

        // Event listener for Add button
        $("#myBtn").on("click", function () {
            showModal("#myModal");
        });

        // Event listener for Edit button
        $(".btn-edit").on("click", function () {
            var userId = $(this).data('id');
            showModal("#editModal-" + userId);
        });

        // Event listener for Delete button
        $(".btn-delete").on("click", function () {
            var userId = $(this).data('id');
            showModal("#deleteModal-" + userId);
        });

        // Event listener for Close button
        $(".close").on("click", function () {
            hideModals();
        });

        // Close modals when clicking outside of the modal content
        $(window).on("click", function (event) {
            if ($(event.target).hasClass("modal")) {
                hideModals();
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('halaman.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Web\bamboo\resources\views/admin/adminForm.blade.php ENDPATH**/ ?>