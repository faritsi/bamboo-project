<div id="">
    <h1>KONROL</h1>
    <?php echo $__env->yieldContent('content'); ?>
</div><?php /**PATH D:\Project\Web\bamboo\resources\views/admin/home.blade.php ENDPATH**/ ?>