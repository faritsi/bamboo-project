<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="/css/style-admin.css" />
</head>
<body>
    <!-- Sidebar -->
    <div id="bg-container">
        <div id="bo-container">
            <div id="container-sidebar">
                <!-- <img src="https://via.placeholder.com/50x50" alt="Image"> -->
                <!-- <h2>Dashboard</h2> -->
                <div id="container-sidebar-menu">
                    <ul>
                        <li>
                            <a href="#">Tambah Admin</a>
                        </li>
                        <li>
                            <a href="#">Tambah Produk</a>
                        </li>
                        <li>
                            <a href="#">Tambah Kegiatan</a>
                        </li>
                        <li>
                            <a href="#">Pimpinan Perusahaan</a>
                        </li>
                    </ul>
                </div>
                <div id="container-logout">
                    <ul>
                        <li>
                            <a href="#">Logout</a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Header Content -->
            <div id="bg-content">
                <div id="bo-content">
                    <?php echo $__env->yieldContent('isi'); ?>
                    <?php echo $__env->make("auth.login", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH D:\Project\Web\bamboo\resources\views/halaman/dashboard_admin.blade.php ENDPATH**/ ?>