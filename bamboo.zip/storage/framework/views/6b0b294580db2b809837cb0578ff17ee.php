<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <script src="//unpkg.com/alpinejs" defer></script>
</head>
<body>
    <div x-data="cart()">
        <div class="cart-icon">
            <button>
                Cart <span x-text="cartCount"></span>
            </button>
        </div>

        <div class="products">
            <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <h2><?php echo e($p->name); ?></h2>
                    <p><?php echo e($p->price); ?></p>
                    <button @click="addToCart(<?php echo e($p->pid); ?>)">Add to Cart</button>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <script>
        function cart() {
            return {
                cartCount: 0,
                addToCart(id) {
                    fetch(`/add-to-cart/${id}`, {
                        method: 'POST',
                        headers: {
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                            'Content-Type': 'application/json'
                        }
                    })
                    .then(response => response.json())
                    .then(data => {
                        this.cartCount = data.cart_count;
                    });
                }
            }
        }
    </script>
</body>
</html>
<?php /**PATH D:\Project\Web\bamboo\resources\views/cart_view/cart.blade.php ENDPATH**/ ?>