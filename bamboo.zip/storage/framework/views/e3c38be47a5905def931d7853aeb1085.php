<a href="<?php echo e(route('produk.create')); ?>"><button type="button" class="btn btn-primary btn-icon-text">
    <i class="mdi mdi-plus-box btn-icon-prepend"></i> Tambah produk </button></a>
<table class="table table-bordered">
    <thead>
      <tr>
        <th> No </th>
        <th> Nama Balita </th>
        <th> Nama Ibu </th>
        <th> Tanggal Lahir </th>
        <th> Jenis Kelamin </th>
        <th> Aksi </th>
      </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td> <?php echo e($p->judul); ?> </td>
        <td> <?php echo e($p->slug); ?> </td>
        <td> <?php echo e($p->deskripsi); ?> </td>
        <td> <?php echo e($p->image); ?> </td>
        <td> <?php echo e($p->tokped); ?> </td>
        <td> <?php echo e($p->shopee); ?> </td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table><?php /**PATH D:\Project\Web\bamboo\resources\views/form/produk.blade.php ENDPATH**/ ?>