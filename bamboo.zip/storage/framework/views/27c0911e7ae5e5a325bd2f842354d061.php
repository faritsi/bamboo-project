<?php $__env->startSection('content'); ?>
<div id="myKegiatan" class="bg-tambah-data">
    <div id="bo-tambah-data">
        <div class="icon-tambah-data">
            <span class="material-symbols-outlined">add</span>                                                        
        </div>
        <div id="text">
            <strong>Kegiatan</strong>
        </div>
    </div>
</div>
<div id="myBtn" class="bg-tambah-data">
    <div id="bo-tambah-data">
        <div class="icon-tambah-data">
            <span class="material-symbols-outlined">add</span>                                                        
        </div>
        <div id="text">
            <strong>Produk</strong>
        </div>
    </div>
</div>

<?php if($errors->has('name')): ?>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            document.getElementById("myActivity").style.display = "block";
        });
    </script>
<?php elseif($errors->has('kode_produk') || $errors->has('nama_produk')): ?>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            document.getElementById("myModal").style.display = "block";
        });
    </script>
<?php endif; ?>


<?php if(session('success')): ?>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            document.getElementById("myModal").style.display = "none";
            document.getElementById("myActivity").style.display = "none";
        });
    </script>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>


<div id="bg-isi-content" class="clearfix">
    <div id="bo-isi-content">
        
        <div id="table-produk">
            <table>
                <thead>
                    <tr>
                        <th rowspan="2"></th>
                        <th rowspan="2">No</th>
                        <th rowspan="2">Nama Produk</th>
                        <th colspan="2">Link Produk</th>
                        <th rowspan="2"></th>
                    </tr>
                    <tr>
                        <th>Tokopedia</th>
                        <th>Shopee</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <div class="btn-details">
                                <span class="material-symbols-outlined">add</span>                                                  
                            </div>
                        </td>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($p->nama_produk); ?></td>
                        <td><?php echo e($p->tokped); ?></td>
                        <td><?php echo e($p->shopee); ?></td>
                        <td>
                            <div id="btn-cfg">
                                <div class="btn-edit" data-id="<?php echo e($p->pid); ?>">
                                    <span class="material-symbols-outlined">edit</span>                                                       
                                </div>
                                <div class="btn-delete" data-id="<?php echo e($p->pid); ?>">
                                    <span class="material-symbols-outlined">delete</span>                                                       
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr class="details-row" style="display: none;">
                        <td colspan="6">
                            <?php if($p->image): ?>
                                <img src="<?php echo e(asset('/storage/' . $p->image)); ?>" alt="" id="avatar-profile">
                            <?php else: ?>
                                <img src="/img/default-img/default.png" alt="" id="avatar-profile">
                            <?php endif; ?>
                            <div><strong>Kode Produk: </strong> <?php echo e($p->kode_produk); ?></div>
                            <div><strong>Nama Produk: </strong> <?php echo e($p->nama_produk); ?></div>
                            <div><strong>Kategori Produk: </strong> <?php echo e($p->kategori->name); ?></div>
                            <div><strong>Jumlah Produk: </strong><?php echo e($p->jumlah_produk); ?></div>
                            <div><strong>Harga: </strong> <?php echo e($p->harga); ?></div>
                            <div><strong>Deskripsi: </strong> <?php echo e($p->deskripsi); ?></div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<div id="myActivity" class="modal" style="display: none;">
    <div class="modal-content">
        <span class="close">&times;</span>
        <form action="<?php echo e(route('kategori.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div id="head-modul">
                <h1>Tambah Kategori</h1>
            </div>
            <div class="form-group">
                <label for="name">Nama Kategori Baru <span class="required">*</span></label>
                <input type="text" id="name" name="name" placeholder="Masukkan Nama Kategiri Baru" value="<?php echo e(old('name')); ?>">
                <?php if($errors->has('name')): ?>
                    <p class="alert alert-danger"><?php echo e($errors->first('name')); ?></p>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <button type="submit" class="submit-btn">Submit</button>
            </div>
        </form>
    </div>
</div>


<div id="myModal" class="modal" style="display: none;">
    <div class="modal-content">
        <span class="close">&times;</span>
        <form action="<?php echo e(route('produk.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div id="head-modul">
                <h1>Tambah Produk</h1>
            </div>
            <div class="thumbnail">
                <img id="thumbnail-preview" src="https://via.placeholder.com/100" alt="Thumbnail">
                <input type="file" id="thumbnail" name="image">
                <?php if($errors->has('image')): ?>
                    <p class="alert alert-danger"><?php echo e($errors->first('image')); ?></p>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="kode_produk">Kode Produk <span class="required">*</span></label>
                <input type="text" id="kode_produk" name="kode_produk" placeholder="EXP-021" value="<?php echo e(old('kode_produk')); ?>">
                <?php if($errors->has('kode_produk')): ?>
                    <p class="alert alert-danger"><?php echo e($errors->first('kode_produk')); ?></p>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="nama_produk">Nama Produk <span class="required">*</span></label>
                <input type="text" id="nama_produk" name="nama_produk" placeholder="Masukan Nama Produk" value="<?php echo e(old('nama_produk')); ?>">
                <?php if($errors->has('nama_produk')): ?>
                    <p class="alert alert-danger"><?php echo e($errors->first('nama_produk')); ?></p>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="kategori_id">Kategori <span class="required">*</span></label>
                <select id="kategori_id" name="kategori_id" class="form-control">
                    <option value="" disabled selected>Pilih Kategori</option>
                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            
            <div class="form-group">
                <label for="jumlah_produk">Jumlah Produk <span class="required">*</span></label>
                <input type="text" id="jumlah_produk" name="jumlah_produk" placeholder="Masukan jumlah produk" value="<?php echo e(old('jumlah_produk')); ?>">
                <?php if($errors->has('jumlah_produk')): ?>
                    <p class="alert alert-danger"><?php echo e($errors->first('jumlah_produk')); ?></p>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="deskripsi">Deskripsi Produk <span class="required">*</span></label>
                <input type="text" id="deskripsi" name="deskripsi" placeholder="Masukan deskripsi produk" value="<?php echo e(old('deskripsi')); ?>">
                <?php if($errors->has('deskripsi')): ?>
                <p class="alert alert-danger"><?php echo e($errors->first('deskripsi')); ?></p>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="tokped">Link Tokopedia <span class="required">*</span></label>
                <input type="text" id="tokped" name="tokped" placeholder="Masukan link tokped" value="<?php echo e(old('tokped')); ?>">
                <?php if($errors->has('tokped')): ?>
                    <p class="alert alert-danger"><?php echo e($errors->first('tokped')); ?></p>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="shopee">Link Shopee <span class="required">*</span></label>
                <input type="text" id="shopee" name="shopee" placeholder="Masukan link shopee" value="<?php echo e(old('shopee')); ?>">
                <?php if($errors->has('shopee')): ?>
                    <p class="alert alert-danger"><?php echo e($errors->first('shopee')); ?></p>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="harga">Harga Produk <span class="required">*</span></label>
                <input type="number" id="harga" name="harga" placeholder="Rp. 9000" value="<?php echo e(old('harga')); ?>">
                <?php if($errors->has('harga')): ?>
                    <p class="alert alert-danger"><?php echo e($errors->first('harga')); ?></p>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <button type="submit" class="submit-btn">Submit</button>
            </div>
        </form>
    </div>
</div>


<!-- Edit Modals -->
<?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div id="editModal-<?php echo e($p->pid); ?>" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <form action="<?php echo e(route('produk.update', $p->pid)); ?>" method="POST" enctype="multipart/form-data" id="categoryForm">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div id="head-modul">
                <h1>Edit Produk</h1>
            </div>
            <div class="thumbnail">
                <input type="hidden" name="oldImage" value="<?php echo e($p->image); ?>">
                <img id="thumbnail-preview-<?php echo e($p->pid); ?>" src="<?php echo e(asset('/storage/' . $p->image)); ?>" alt="Thumbnail">
                <input type="file" id="thumbnail-<?php echo e($p->pid); ?>" name="image">
                <?php if($errors->has('image')): ?>
                    <p class="alert alert-danger"><?php echo e($errors->first('image')); ?></p>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="kode_produk-<?php echo e($p->pid); ?>">Kode Produk <span class="required">*</span></label>
                <input type="text" id="kode_produk-<?php echo e($p->pid); ?>" name="kode_produk" placeholder="Masukan Nama" value="<?php echo e(old('kode_produk', $p->kode_produk)); ?>">
                <?php if($errors->has('kode_produk')): ?>
                    <p class="alert alert-danger"><?php echo e($errors->first('kode_produk')); ?></p>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="nama_produk-<?php echo e($p->pid); ?>">Nama Produk <span class="required">*</span></label>
                <input type="text" id="nama_produk-<?php echo e($p->pid); ?>" name="nama_produk" placeholder="Masukan Nama" value="<?php echo e(old('nama_produk', $p->nama_produk)); ?>">
                <?php if($errors->has('nama_produk')): ?>
                    <p class="alert alert-danger"><?php echo e($errors->first('nama_produk')); ?></p>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="kategori">Kategori <span class="required">*</span></label>
                <div class="dropdown">
                    <button class="dropbtn" type="button" id="dropdownButton">Pilih Kategori</button>
                    <div class="dropdown-content" id="dropdownMenu">
                        <a href="#" data-value="awet">Awet</a>
                        <a href="#" data-value="mudah-pecah">Mudah Pecah</a>
                        <a href="#" data-value="tahan-lama">Tahan Lama</a>
                    </div>
                </div>
                <input type="text" id="jenis_produk-<?php echo e($p->pid); ?>" name="jenis_produk" value="<?php echo e(old('jenis_produk', $p->jenis_produk)); ?>">        
                <?php if($errors->has('jenis_produk')): ?>
                    <p class="alert alert-danger"><?php echo e($errors->first('jenis_produk')); ?></p>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="jumlah_produk-<?php echo e($p->pid); ?>">Jumlah Produk <span class="required">*</span></label>
                <input type="text" id="jumlah_produk-<?php echo e($p->pid); ?>" name="jumlah_produk" placeholder="Masukan jumlah_produk" value="<?php echo e(old('jumlah_produk', $p->jumlah_produk)); ?>">
                <?php if($errors->has('jumlah_produk')): ?>
                    <p class="alert alert-danger"><?php echo e($errors->first('jumlah_produk')); ?></p>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="deskripsi-<?php echo e($p->pid); ?>">Deskripsi Produk <span class="required">*</span></label>
                <input type="text" id="deskripsi-<?php echo e($p->pid); ?>" name="deskripsi" placeholder="Masukan Pengalaman" value="<?php echo e(old('deskripsi', $p->deskripsi)); ?>">
                <?php if($errors->has('deskripsi')): ?>
                <p class="alert alert-danger"><?php echo e($errors->first('deskripsi')); ?></p>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="tokped-<?php echo e($p->pid); ?>">Link Tokopedia <span class="required">*</span></label>
                <input type="text" id="tokped-<?php echo e($p->pid); ?>" name="tokped" placeholder="Masukan tokped" value="<?php echo e(old('tokped', $p->tokped)); ?>">
                <?php if($errors->has('tokped')): ?>
                    <p class="alert alert-danger"><?php echo e($errors->first('tokped')); ?></p>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="shopee-<?php echo e($p->pid); ?>">Link Shopee <span class="required">*</span></label>
                <input type="text" id="shopee-<?php echo e($p->pid); ?>" name="shopee" placeholder="Masukan shopee" value="<?php echo e(old('shopee', $p->shopee)); ?>">
                <?php if($errors->has('shopee')): ?>
                    <p class="alert alert-danger"><?php echo e($errors->first('shopee')); ?></p>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="harga-<?php echo e($p->pid); ?>">Harga Produk <span class="required">*</span></label>
                <input type="text" id="harga-<?php echo e($p->pid); ?>" name="harga" placeholder="Masukan harga" value="<?php echo e(old('harga', $p->harga)); ?>">
                <?php if($errors->has('harga')): ?>
                    <p class="alert alert-danger"><?php echo e($errors->first('harga')); ?></p>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <button type="submit" class="submit-btn">Submit</button>
            </div>
        </form>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- Delete Modal -->
<?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div id="deleteModal-<?php echo e($p->pid); ?>" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <form action="<?php echo e(route('produk.destroy', $p->pid)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <div id="head-modul">
                <h1>Delete Produk</h1>
            </div>
            <p>Are you sure you want to delete <?php echo e($p->nama_produk); ?>?</p>
            <div class="form-group">
                <button type="submit" class="submit-btn">Delete</button>
            </div>
        </form>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>
    $(document).ready(function () {
        $(".btn-details").on("click", function () {
            var row = $(this).closest("tr").next(".details-row");
            row.toggle();
            var icon = $(this).find(".material-symbols-outlined");
            if (row.is(":visible")) {
                icon.text("remove");
                $(this).addClass("red");
            } else {
                icon.text("add");
                $(this).removeClass("red");
            }
        });

        function showModal(modalId) {
            $(modalId).show();
        }
        
        function showKegiatan(modalId) {
            $(modalId).show();
        }

        function hideModals() {
            $(".modal").hide();
        }
        // Tambah Produk
        $("#myBtn").on("click", function () {
            showModal("#myModal");
        });
        // Tambah Kegiatan
        $("#myKegiatan").on("click", function () {
            showKegiatan("#myActivity");
        });

        $(".close").on("click", function () {
            hideModals();
        });

        $(window).on("click", function (event) {
            if ($(event.target).hasClass("modal")) {
                hideModals();
            }
        });

        $('.thumbnail').on('click', function() {
            $(this).find('input[type="file"]').click();
        });

        $('input[type="file"]').on('change', function(event) {
            var reader = new FileReader();
            var preview = $(this).siblings('img');
            reader.onload = function() {
                preview.attr('src', reader.result);
            }
            reader.readAsDataURL(event.target.files[0]);
        });

        $(".btn-edit").on("click", function () {
            var ppid = $(this).data('id');
            showModal("#editModal-" + ppid);
        });

        $(".btn-delete").on("click", function () {
            var ppid = $(this).data('id');
            showModal("#deleteModal-" + ppid);
        });
        
        $(".dropdown").on("click", function() {
            $(this).find(".dropdown-content").toggle();
        });

        $(window).on("click", function(event) {
            if (!$(event.target).closest(".dropdown").length) {
                $(".dropdown-content").hide();
            }
        });

        <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            // Set the dropdown button text based on the hidden input value on page load
            var existingValue = $("#jenis_produk-<?php echo e($p->pid); ?>").val();
            if (existingValue) {
                $("#dropdownButton-<?php echo e($p->pid); ?>").text(existingValue);
            }

            // Toggle dropdown menu visibility
            $("#dropdownButton-<?php echo e($p->pid); ?>").on("click", function(event) {
                event.preventDefault();
                $("#dropdownMenu-<?php echo e($p->pid); ?>").toggleClass("show");
            });

            // Handle click event on dropdown menu items
            $("#dropdownMenu-<?php echo e($p->pid); ?> a").on("click", function(event) {
                event.preventDefault();
                var selectedCategory = $(this).data('value');
                $("#dropdownButton-<?php echo e($p->pid); ?>").text(selectedCategory); // Update dropdown button text
                $("#dropdownMenu-<?php echo e($p->pid); ?>").removeClass("show"); // Hide dropdown menu
                $("#jenis_produk-<?php echo e($p->pid); ?>").val(selectedCategory); // Update hidden input value
            });

            // Close the dropdown if the user clicks outside of it
            $(window).on("click", function(event) {
                if (!event.target.matches('#dropdownButton-<?php echo e($p->pid); ?>')) {
                    $("#dropdownMenu-<?php echo e($p->pid); ?>").removeClass("show");
                }
            });
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        $(document).ready(function() {
    // Tampilkan dropdown
            $("#dropdownButton").on("click", function(event) {
                event.preventDefault();
                $("#dropdownMenu").toggleClass("show");
            });

            // Pilih kategori dan simpan ke input tersembunyi
            $("#dropdownMenu a").on("click", function(event) {
                event.preventDefault();
                var selectedCategory = $(this).data('value');
                $("#dropdownButton").text(selectedCategory); // Ubah teks tombol dropdown
                $("#dropdownMenu").removeClass("show"); // Sembunyikan menu dropdown
                $("input[name='kategori']").val(selectedCategory); // Simpan nilai ke input tersembunyi
            });

            // Tutup dropdown jika klik di luar
            $(window).on("click", function(event) {
                if (!event.target.matches('#dropdownButton')) {
                    $("#dropdownMenu").removeClass("show");
                }
            });
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('halaman.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Web\bamboo\resources\views/admin/produk.blade.php ENDPATH**/ ?>