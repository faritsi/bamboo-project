<?php $__env->startSection('content'); ?>
<div id="myBtn" class="bg-tambah-data">
    <div id="bo-tambah-data">
        <div class="icon-tambah-data">
            <span class="material-symbols-outlined">
            add
            </span>                                                        
        </div>
        <div id="text">
            <strong>Pimpinan</strong>
        </div>
    </div>
</div>

<?php if($errors->any()): ?>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        document.getElementById("myModal").style.display = "block";
    });
</script>
<?php endif; ?>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<div id="bg-isi-content" class="clearfix">
    <div id="bo-isi-content">
        
        <div id="table-pimpinan">
            <table>
                <thead>
                    <tr>
                        <th></th>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Jabatan</th>
                        <th>Pengalaman</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pimpinan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <div class="btn-details">
                                <span class="material-symbols-outlined">
                                add
                                </span>                                                        
                            </div>
                        </td>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($p->name); ?></td>
                        <td><?php echo e($p->jabatan); ?></td>
                        <td><?php echo e($p->deskripsi); ?></td>
                        <td>
                            <div id="btn-cfg">
                                <div class="btn-edit" data-id="<?php echo e($p->ppid); ?>">
                                    <span class="material-symbols-outlined">
                                    edit
                                    </span>                                                       
                                </div>
                                <div class="btn-delete" data-id="<?php echo e($p->ppid); ?>">
                                    <span class="material-symbols-outlined">
                                    delete
                                    </span>                                                       
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr class="details-row">
                        <td colspan="6">
                            <?php if($p->image): ?>
                                <img src="<?php echo e(asset('/storage/' . $p->image)); ?>" alt="" id="avatar-profile">
                            <?php else: ?>
                                <img src="/img/default-img/default.png" alt="" id="avatar-profile">
                            <?php endif; ?>
                            
                            <div><strong>Nama Pimpinan: </strong> <?php echo e($p->name); ?></div>
                            <div><strong>Jabatan: </strong> <?php echo e($p->jabatan); ?></div>
                            <div><strong>Pengalaman : </strong> <?php echo e($p->deskripsi); ?></div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Modal -->
<div id="myModal" class="modal">
    <div class="modal-content">
      <span class="close">&times;</span>
      <form action="<?php echo e(route('pimpinan.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
          <div id="head-modul">
            <h1>Tambah Pimpinan</h1>
          </div>
          <div class="thumbnail">
            <img id="thumbnail-preview" src="https://via.placeholder.com/100" alt="Thumbnail">
            <input type="file" id="thumbnail" name="image">
            <?php if($errors->has('image')): ?>
                <p class="alert alert-danger"><?php echo e($errors->first('image')); ?></p>
            <?php endif; ?>
          </div>
          <div class="form-group">
              <label for="name">Nama Pimpinan <span class="required">*</span></label>
              <input type="text" id="name" name="name" placeholder="Masukan Nama" value="<?php echo e(old('name')); ?>">
              <?php if($errors->has('name')): ?>
                  <p class="alert alert-danger"><?php echo e($errors->first('name')); ?></p>
              <?php endif; ?>
          </div>
          <div class="form-group">
              <label for="jabatan">Jabatan <span class="required">*</span></label>
              <input type="text" id="jabatan" name="jabatan" placeholder="Masukan Jabatan" value="<?php echo e(old('jabatan')); ?>">
              <?php if($errors->has('jabatan')): ?>
                  <p class="alert alert-danger"><?php echo e($errors->first('jabatan')); ?></p>
              <?php endif; ?>
          </div>
          <div class="form-group">
              <label for="deskripsi">Pengalaman <span class="required">*</span></label>
              <input type="text" id="deskripsi" name="deskripsi" placeholder="Masukan Pengalaman" value="<?php echo e(old('deskripsi')); ?>">
              <?php if($errors->has('deskripsi')): ?>
                  <p class="alert alert-danger"><?php echo e($errors->first('deskripsi')); ?></p>
              <?php endif; ?>
          </div>
          <div class="form-group">
            <button type="submit" class="submit-btn">Submit</button>
          </div>
      </form>
    </div>
</div>

<!-- Edit Modals -->
<?php $__currentLoopData = $pimpinan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div id="editModal-<?php echo e($p->ppid); ?>" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <form action="<?php echo e(route('pimpinan.update', $p->ppid)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div id="head-modul">
                <h1>Edit Pimpinan</h1>
            </div>
            <div class="thumbnail">
                <input type="hidden" name="oldImage" value="<?php echo e($p->image); ?>">
                <img id="thumbnail-preview-<?php echo e($p->ppid); ?>" src="<?php echo e(asset('/storage/' . $p->image)); ?>" alt="Thumbnail">
                <input type="file" id="thumbnail-<?php echo e($p->ppid); ?>" name="image">
                <?php if($errors->has('image')): ?>
                    <p class="alert alert-danger"><?php echo e($errors->first('image')); ?></p>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="name-<?php echo e($p->ppid); ?>">Nama Pimpinan <span class="required">*</span></label>
                <input type="text" id="name-<?php echo e($p->ppid); ?>" name="name" placeholder="Masukan Nama" value="<?php echo e(old('name', $p->name)); ?>">
                <?php if($errors->has('name')): ?>
                    <p class="alert alert-danger"><?php echo e($errors->first('name')); ?></p>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="jabatan-<?php echo e($p->ppid); ?>">Jabatan <span class="required">*</span></label>
                <input type="text" id="jabatan-<?php echo e($p->ppid); ?>" name="jabatan" placeholder="Masukan Jabatan" value="<?php echo e(old('jabatan', $p->jabatan)); ?>">
                <?php if($errors->has('jabatan')): ?>
                    <p class="alert alert-danger"><?php echo e($errors->first('jabatan')); ?></p>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="deskripsi-<?php echo e($p->ppid); ?>">Pengalaman <span class="required">*</span></label>
                <input type="text" id="deskripsi-<?php echo e($p->ppid); ?>" name="deskripsi" placeholder="Masukan Pengalaman" value="<?php echo e(old('deskripsi', $p->deskripsi)); ?>">
                <?php if($errors->has('deskripsi')): ?>
                    <p class="alert alert-danger"><?php echo e($errors->first('deskripsi')); ?></p>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <button type="submit" class="submit-btn">Submit</button>
            </div>
        </form>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<!-- Delete Modal -->
<?php $__currentLoopData = $pimpinan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div id="deleteModal-<?php echo e($p->ppid); ?>" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <form action="<?php echo e(route('pimpinan.destroy', $p->ppid)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <div id="head-modul">
                <h1>Delete Pimpinan</h1>
            </div>
            <p>Are you sure you want to delete <?php echo e($p->name); ?>?</p>
            <div class="form-group">
                <button type="submit" class="submit-btn">Delete</button>
            </div>
        </form>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>
    $(document).ready(function () {
    $(".btn-details").on("click", function () {
        var row = $(this).closest("tr").next(".details-row");
        row.toggle();
        var icon = $(this).find(".material-symbols-outlined");
        if (row.is(":visible")) {
            icon.text("remove");
            $(this).addClass("red");
        } else {
            icon.text("add");
            $(this).removeClass("red");
        }
    });

    function showModal(modalId) {
        $(modalId).show();
    }

    function hideModals() {
        $(".modal").hide();
    }

    $("#myBtn").on("click", function () {
        showModal("#myModal");
    });

    $(".close").on("click", function () {
        hideModals();
    });

    $(window).on("click", function (event) {
        if ($(event.target).hasClass("modal")) {
            hideModals();
        }
    });

    $('.thumbnail').on('click', function() {
        $(this).find('input[type="file"]').click();
    });

    $('input[type="file"]').on('change', function(event) {
        var reader = new FileReader();
        var preview = $(this).siblings('img');
        reader.onload = function() {
            preview.attr('src', reader.result);
        }
        reader.readAsDataURL(event.target.files[0]);
    });

    // Event listener for Edit button
    $(".btn-edit").on("click", function () {
        var ppid = $(this).data('id');
        showModal("#editModal-" + ppid);
    });

    // Event listener for Delete button
    $(".btn-delete").on("click", function () {
        var ppid = $(this).data('id');
        showModal("#deleteModal-" + ppid);
    });
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('halaman.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Web\bamboo\resources\views/admin/pimpinan.blade.php ENDPATH**/ ?>