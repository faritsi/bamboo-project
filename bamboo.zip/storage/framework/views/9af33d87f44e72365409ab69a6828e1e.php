<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visitor Statistics</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .summary-box {
            background-color: white;
            color: black;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            border: 1px solid #ddd;
            width: 250px;
            margin: 20px auto;
        }

        .chart-container {
            width: 80%;
            margin: 0 auto;
        }

        .summary-container {
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="chart-container">
        <canvas id="visitorChart"></canvas>
    </div>

    <div class="summary-container">
        <div class="summary-box">
            <h4>Visitor Stats</h4>
            <p>Today: <?php echo e($today); ?></p>
            <p>This Week: <?php echo e($thisWeek); ?></p>
            <p>This Month: <?php echo e($thisMonth); ?></p>
            <p>Total: <?php echo e($totalVisits); ?></p>
        </div>
    </div>

    <script>
        const ctx = document.getElementById('visitorChart').getContext('2d');
        const visitorData = {
            labels: [
                <?php $__currentLoopData = $dailyVisitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    "<?php echo e($visitor->date); ?>",
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            datasets: [{
                label: 'Daily Visitors',
                data: [
                    <?php $__currentLoopData = $dailyVisitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($visitor->count); ?>,
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ],
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        };

        const visitorChart = new Chart(ctx, {
            type: 'bar', // Change this to 'line' if you prefer a line chart
            data: visitorData,
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>
<?php /**PATH D:\Project\Web\bamboo\resources\views/admin/pengunjung.blade.php ENDPATH**/ ?>