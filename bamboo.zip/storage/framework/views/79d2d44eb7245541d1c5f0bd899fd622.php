<form action="<?php echo e(route('produk.store')); ?>" method="POST">
    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p class="alert alert-danger"><?php echo e($err); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <?php echo csrf_field(); ?>
    <input class="form-control" type="text" name="judul" placeholder="Judul">
    <input class="form-control" type="text" name="slug" placeholder="slug">
    <input class="form-control" type="text" name="deskripsi" placeholder="deskripsi">
    <input class="form-control" type="text" name="image" placeholder="image">
    <input class="form-control" type="text" name="tokped" placeholder="tokped">
    <input class="form-control" type="text" name="shopee" placeholder="shopee">
    <button type="submit" class="btn btn-primary me-2">Submit</button>
</form><?php /**PATH D:\Project\Web\bamboo\resources\views/form/add-produk.blade.php ENDPATH**/ ?>