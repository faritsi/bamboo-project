
<?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div id="modalUpdate<?php echo e($p->pid); ?>" class="modal">
    <div class="modal-content">
        <span class="close-btn">&times;</span>
        <h2>Edit Produk</h2>
        <form action="<?php echo e(route('produk.update', $p->pid)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <input type="text" id="pid" name="pid" value="<?php echo e($p->pid); ?>" hidden>
            <label for="judul">Judul:</label>
            <input type="text" id="judul" name="judul" value="<?php echo e($p->judul); ?>" required>
            <label for="slug">Slug:</label>
            <input type="text" id="slug" name="slug" value="<?php echo e($p->slug); ?>" required>
            <?php if($p->image): ?> 
                <img src="<?php echo e(asset('images/' . $p->image)); ?>" alt="" class="img-preview">
            <?php else: ?>            
                <img class="img-preview" style="display: block; max-width: 100px; height: auto;">
            <?php endif; ?>
            <label for="image">Image:</label>
            <input type="file" id="image" name="image" onchange="previewImage()">
            <label for="deskripsi">Deskripsi:</label>
            <input type="text" id="deskripsi" name="deskripsi" value="<?php echo e($p->deskripsi); ?>" required>
            <label for="tokped">Tokopedia:</label>
            <input type="text" id="tokped" name="tokped" value="<?php echo e($p->tokped); ?>" required>
            <label for="shopee">Shopee:</label>
            <input type="text" id="shopee" name="shopee" value="<?php echo e($p->shopee); ?>" required>
            <button type="submit">Submit</button>
        </form>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script>
    function previewImage() {
        const image = document.querySelector("#image");
        const imgPreview = document.querySelector(".img-preview");

        imgPreview.style.display = "block";
        const oFReader = new FileReader();
        oFReader.readAsDataURL(image.files[0]);

        oFReader.onload = function (oFREvent) {
            imgPreview.src = oFREvent.target.result;
        };
    }
</script><?php /**PATH D:\Project\Web\bamboo\resources\views/modal/modal-edit.blade.php ENDPATH**/ ?>