
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div id="modalUpdate<?php echo e($u->id); ?>" class="modal">
    <div class="modal-content">
        <span class="close-btn">&times;</span>
        <h2>Edit Admin</h2>
        <form action="<?php echo e(route('admin.update', $u->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <label for="name">Nama:</label>
            <input type="text" id="name" name="name" value="<?php echo e($u->name); ?>" required>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" value="<?php echo e($u->username); ?>" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <label for="password">Konfirmasi Password:</label>
            <input type="password" name="password_confirm" placeholder="Konfirmasi Password" required>
            
            <input type="text" id="role" name="role_id" required value="<?php echo e($u->role_id); ?>" hidden>
            
            <input type="text" id="status" name="status" value="aktif" hidden>
            <button type="submit">Submit</button>
        </form>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script>
    function previewImage() {
        const image = document.querySelector("#image");
        const imgPreview = document.querySelector(".img-preview");

        imgPreview.style.display = "block";
        const oFReader = new FileReader();
        oFReader.readAsDataURL(image.files[0]);

        oFReader.onload = function (oFREvent) {
            imgPreview.src = oFREvent.target.result;
        };
    }
</script><?php /**PATH D:\Project\Web\bamboo\resources\views/modal-admin/admin-edit.blade.php ENDPATH**/ ?>