<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e($title); ?></title>
    <link rel="stylesheet" href="/css/style-login.css" />
</head>
<body>
    <div class="square-container">
        <div class="left-section">
            <img
                src="https://via.placeholder.com/800x600"
                alt="Background Placeholder Image"
                class="background-image"
            />
            <div class="logo-container">
                <img src="logo.png" alt="Logo" class="logo" />
            </div>
        </div>
        <div class="right-section">
            <div class="login-form">
                <h2>Login</h2>
                <form action="<?php echo e(url('login/proses')); ?>" method="post">
                <?php echo csrf_field(); ?>
                    <input type="text" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="username" placeholder="username" name="username">
                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input type="password" class="form-control" id="password" placeholder="Password" name="password">
                    <button type="submit">Login</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH D:\Project\Web\bamboo\resources\views/auth/login.blade.php ENDPATH**/ ?>