<?php $__currentLoopData = $pimpinan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div id="modalDelete<?php echo e($p->ppid); ?>" class="modal">
    <div class="modal-content">
        <span class="close-btn">&times;</span>
        <h2>Konfirmasi Hapus</h2>
        <p>Apakah Anda yakin ingin menghapus produk ini?</p>
        <form action="<?php echo e(route('pimpinan.destroy', $p->ppid)); ?>" method="POST">
            <?php echo method_field('DELETE'); ?>
            <?php echo csrf_field(); ?>
            <button type="submit">Hapus</button>
        </form>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\Project\Web\bamboo\resources\views/modal-pimpinan/pimpinan-delet.blade.php ENDPATH**/ ?>