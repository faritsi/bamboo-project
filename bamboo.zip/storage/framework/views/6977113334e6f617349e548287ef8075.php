
<?php $__currentLoopData = $pimpinan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div id="modalUpdate<?php echo e($u->ppid); ?>" class="modal">
    <div class="modal-content">
        <span class="close-btn">&times;</span>
        <h2>Edit Profil</h2>
        <form action="<?php echo e(route('pimpinan.update', $u->ppid)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p class="hayo"><?php echo e($err); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <input type="text" id="ppid" name="ppid" value="<?php echo e($u->ppid); ?>" hidden>
            <label for="name">Nama:</label>
            <input type="text" id="name" name="name" value="<?php echo e($u->name); ?>" required>
            <label for="username">Jabatan:</label>
            <input type="text" id="jabatan" name="jabatan" value="<?php echo e($u->jabatan); ?>" required>
            <label for="username">deskripsi:</label>
            <input type="text" id="deskripsi" name="deskripsi" value="<?php echo e($u->deskripsi); ?>" required>
            <label for="username">image:</label>
            
            <div class="form-group">
                <?php if($u->image): ?>
                    <img src="<?php echo e(asset('images/' . $u->image)); ?>">
                <?php else: ?>
                        <p>No image found</p>
                <?php endif; ?>
                    image <input type="file" name="image" value="<?php echo e($u->image); ?>"/>
            </div>
            <button type="submit">Submit</button>
        </form>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script>
    function previewImage() {
        const image = document.querySelector("#image");
        const imgPreview = document.querySelector(".img-preview");

        imgPreview.style.display = "block";
        const oFReader = new FileReader();
        oFReader.readAsDataURL(image.files[0]);

        oFReader.onload = function (oFREvent) {
            imgPreview.src = oFREvent.target.result;
        };
    }
</script><?php /**PATH D:\Project\Web\bamboo\resources\views/modal-pimpinan/pimpinan-edit.blade.php ENDPATH**/ ?>